//奶茶
#import "IGGView.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <UIKit/UIAlertView.h>
#import <UIKit/UIControl.h>
#include <JRMemory/MemScan.h>
#import "Offset.h"



@interface IGGView()
@end
UIButton *openButton;
UIButton *closeButton;
UIView *menuView;
UIButton *clean;
UIButton *BGrass;
UIButton *btn;
UIView *menu;
@implementation IGGView

#pragma mark -------------------------------------View-------------------------------------------

+ (void)load
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        IGGView *view = [IGGView View];
        [view show];
        [[[[UIApplication sharedApplication] windows]lastObject] addSubview:view];
//New Application Windows
      UIWindow*Window = [UIApplication sharedApplication].keyWindow;



 

//Open menu with 3 finger
   openButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    openButton.frame = CGRectMake(170,([[UIScreen mainScreen] bounds].size.height)-350, 70, 40);
    openButton.backgroundColor = [UIColor blackColor];
openButton.layer.borderColor = [[UIColor greenColor] CGColor];
    openButton.layer.borderWidth = 1.5;
    openButton.layer.cornerRadius = 5;
    [openButton setTitle:@"OPEN" forState:UIControlStateNormal];
    [openButton setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [openButton addTarget:self action:@selector(expand) forControlEvents:UIControlEventTouchUpInside];
    openButton.hidden = NO; 
    [Window addSubview:openButton];



UILabel *myLabel = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width / 4 - 5, 0, [UIScreen mainScreen].bounds.size.width / 2  + 10, 20)];
myLabel.textColor = [UIColor cyanColor];
myLabel.numberOfLines = 0;
myLabel.text = [NSString stringWithFormat:@"HFT Channel"];
myLabel.textAlignment = NSTextAlignmentCenter;
myLabel.shadowOffset = CGSizeMake(1,1); 
myLabel.backgroundColor = [UIColor clearColor];
[Window addSubview:myLabel];
    });
}





+ (instancetype)View
{
    return [[IGGView alloc] initWithFrame:[UIScreen mainScreen].bounds];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = NO;
  
    }
    return self;
}

- (void)show
{
    self.hidden = NO;

}
#pragma mark -------------------------------------Event-------------------------------------------
//Start creating menu
+ (void)expand {


     //New menu view
    UIWindow*mainWindow;
    mainWindow = [UIApplication sharedApplication].keyWindow;



    menuView = [[UIView alloc] 
    initWithFrame:CGRectMake(0,0, 350, [[UIScreen mainScreen] bounds].size.height)];//menu size height
    menuView.backgroundColor=[UIColor blackColor];//Color
    menuView.layer.cornerRadius = 5;//Radious corner
    menuView.hidden=NO;//whether to hide
    [mainWindow addSubview:menuView];  
    //Create a close menu button
   closeButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    closeButton.frame = CGRectMake(280,([[UIScreen mainScreen] bounds].size.height)-40, 30, 30);
    [closeButton setTitle:@"❌" forState:UIControlStateNormal];
    [closeButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
closeButton.layer.borderColor = [[UIColor whiteColor] CGColor];
    closeButton.layer.borderWidth = 1.5f;
    closeButton.layer.cornerRadius = 10;
    [closeButton addTarget:self action:@selector(closeMenu) forControlEvents:UIControlEventTouchUpInside];
    closeButton.hidden = NO; 
    [menuView addSubview:closeButton];
 



       //Define to store multiple data
     NSUserDefaults*defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];

    //添加开关功能
    UISwitch* SW1 = [[UISwitch alloc] initWithFrame:CGRectMake(0.5, 16, 51, 31)];
    SW1.thumbTintColor = [UIColor whiteColor];
    SW1.onTintColor = [UIColor colorWithRed: 1.00 green: 0.95 blue: 0.74 alpha: 1.00];
    SW1.tintColor = [UIColor blueColor];
    [SW1 addTarget:self action:@selector(feature1:)  forControlEvents:UIControlEventValueChanged];
    [menuView addSubview:SW1];
   //定义开关默认开启
   BOOL sw1 = [defaults boolForKey:@"sw1"];
    if (sw1 == YES) { [SW1 setOn:YES];   } 
    else { [SW1 setOn:NO];     }
     UILabel* AL1 = [[UILabel alloc] initWithFrame:CGRectMake(54, 12.5, 200, 40)];
      [AL1 setText:@"Fix Dame Heashot 100%"];
      [AL1 setTextColor:[UIColor whiteColor] ];
      [AL1 setBackgroundColor:[UIColor clearColor]];
       AL1.font = [UIFont systemFontOfSize:15];
      [menuView addSubview:AL1];


   UISwitch* SW2 = [[UISwitch alloc] initWithFrame:CGRectMake(149, 16, 51, 31)];
    SW2.thumbTintColor = [UIColor whiteColor];
    SW2.onTintColor = [UIColor redColor];
    SW2.tintColor = [UIColor whiteColor];
    [SW2 addTarget:self action:@selector(feature2:)  forControlEvents:UIControlEventValueChanged];
    [menuView addSubview:SW2];
   
   BOOL sw2 = [defaults boolForKey:@"sw2"];
    if (sw2 == YES) { [SW2 setOn:YES];   } 
    else { [SW2 setOn:NO];     }
      UILabel* AL2 = [[UILabel alloc] initWithFrame:CGRectMake(205, 10.5, 200, 40)];
      [AL2 setText:@"No Recoil"];
      [AL2 setTextColor:[UIColor whiteColor] ];
      [AL2 setBackgroundColor:[UIColor clearColor]];
       AL2.font = [UIFont systemFontOfSize:15];
      [menuView addSubview:AL2];


//范围
    UISwitch* SW3 = [[UISwitch alloc] initWithFrame:CGRectMake(0, 61.5, 51, 31)];
    SW3.thumbTintColor = [UIColor whiteColor];
    SW3.onTintColor = [UIColor cyanColor];
    SW3.tintColor = [UIColor redColor];
    [SW3 addTarget:self action:@selector(feature3:)  forControlEvents:UIControlEventValueChanged];
    [menuView addSubview:SW3];
   //定义开关默认开启
   BOOL sw3 = [defaults boolForKey:@"sw3"];
    if (sw3 == YES) { [SW3 setOn:YES];   } 
    else { [SW3 setOn:NO];     }
      UILabel* AL3 = [[UILabel alloc] initWithFrame:CGRectMake(51, 58.5, 200, 40)];
      [AL3 setText:@"Reset Tk"];
      [AL3 setTextColor:[UIColor whiteColor] ];
      [AL3 setBackgroundColor:[UIColor clearColor]];
       AL3.font = [UIFont systemFontOfSize:15];
      [menuView addSubview:AL3];

      
  
}



//无后
+ (void)feature1:(UISwitch *)SW1 {
    
    if ([SW1 isOn]) {
//开启
 
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    [defaults setBool:YES forKey:@"sw1"];

    [defaults synchronize];

//填写功能代码
        
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x160000000};
        float search = 9000;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = -20;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }//全改

    } else {

    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x200000000};
        float search = -20;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float); 
        vector<void*>results = engine.getAllResults();
        float modify = 9000;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);

        }
//关闭
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    [defaults setBool:NO forKey:@"sw1"];

    [defaults synchronize];


    


}}

//透视
+ (void)feature2:(UISwitch *)SW2 {
    
    if ([SW2 isOn]) {
//开启
 
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    [defaults setBool:YES forKey:@"sw2"];

    [defaults synchronize];

//填写功能代码

HOOK(0x103D51510, KHHMBLDMKEN, old_KHHMBLDMKEN);
        }//全改

    } else {
//关闭
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    [defaults setBool:NO forKey:@"sw2"];

    [defaults synchronize];

}}

//范围
+ (void)feature3:(UISwitch *)SW3 {
    
    if ([SW3 isOn]) {
//开启
 
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    [defaults setBool:YES forKey:@"sw3"];

    [defaults synchronize];

//填写功能代码

HOOK(0x101B39064, get_Resetguest, old_get_Resetguest);


    } else {
//关闭
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    [defaults setBool:NO forKey:@"sw3"];

    [defaults synchronize];

}}

    


      
    
    
    
    
 
}
}




//无后





//创建关闭菜单
+ (void)closeMenu { menuView.hidden = YES; } 


@end

