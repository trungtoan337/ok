//奶茶
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IGGView : UIView

+ (instancetype)View;
- (void)show;
+ (void)closeMenu;
+ (void)expand;
+ (void)feature1:(UISwitch *)SW1;
+ (void)feature2:(UISwitch *)SW2;
+ (void)feature3:(UISwitch *)SW3;
+ (void)feature4:(UISwitch *)SW4;
+ (void)feature5:(UISwitch *)SW5;
+ (void)feature6:(UISwitch *)SW6;
+ (void)feature7:(UISwitch *)SW7;
+ (void)feature8:(UISwitch *)SW8;
+ (void)feature9:(UISwitch *)SW9;
+ (void)feature10:(UISwitch *)SW10;
+ (void)feature11:(UISwitch *)SW11;
+ (void)feature12:(UISwitch *)SW12;
+ (void)cleandata;
+ (void)feature;
+ (void)BGrass:(id)sender;
@end

NS_ASSUME_NONNULL_END
